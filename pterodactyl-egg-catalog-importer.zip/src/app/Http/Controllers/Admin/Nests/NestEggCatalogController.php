<?php

/**
 * Nest-scoped egg catalog HTTP endpoints for Pterodactyl admin.
 *
 * Copyright (c) 2026 Derek Allison / Chapter22 Hosting
 * Licensed under the MIT License.
 */


namespace Pterodactyl\Http\Controllers\Admin\Nests;

use Throwable;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Models\Nest;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\MassEggImporter\MassEggImporterService;
use Pterodactyl\Services\Eggs\Sharing\EggImporterService;

class NestEggCatalogController extends Controller
{
    public function __construct(protected MassEggImporterService $catalogService)
    {
        $this->middleware(function ($request, $next) {
            if (filter_var(env('IS_DEMO', false), FILTER_VALIDATE_BOOLEAN)) {
                abort(403, 'This section is disabled on the demo site.');
            }

            return $next($request);
        });
    }

    /**
     * Return the public egg catalogue (categories + eggs).
     */
    public function catalogue(Nest $nest): JsonResponse
    {
        // Nest is required in the route so this stays nest-scoped for auth/audit context.
        try {
            $data = $this->catalogService->fetchCatalogue();
        } catch (Throwable $exception) {
            return response()->json(['error' => $exception->getMessage() ?: 'Failed to fetch egg catalogue.'], 500);
        }

        return response()->json($data);
    }

    /**
     * Import one egg from a catalogue download URL or pasted JSON URL into this nest.
     */
    public function import(Request $request, Nest $nest): JsonResponse
    {
        $validated = $request->validate([
            'download_url' => 'required|url|max:2048',
            'egg_id' => 'nullable|string|max:255',
            'replace' => 'sometimes|boolean',
        ]);

        $replace = $request->boolean('replace');

        try {
            $result = $this->catalogService->importFromUrl(
                (string) $validated['download_url'],
                (int) $nest->id,
                $replace,
                isset($validated['egg_id']) ? (string) $validated['egg_id'] : null,
            );
            $this->catalogService->clearRelevantCaches();

            $egg = $result['egg'];

            return response()->json([
                'success' => true,
                'replaced' => $result['replaced'],
                'egg' => [
                    'id' => $egg->id,
                    'name' => $egg->name,
                    'nest_id' => $egg->nest_id,
                ],
            ]);
        } catch (Throwable $exception) {
            $status = str_contains($exception->getMessage(), 'already exists') ? 409 : 422;

            return response()->json(['error' => $exception->getMessage() ?: 'Failed to import egg from URL.'], $status);
        }
    }

    /**
     * Bulk-import multiple catalogue eggs into this nest.
     */
    public function importBulk(Request $request, Nest $nest): JsonResponse
    {
        $validated = $request->validate([
            'replace' => 'sometimes|boolean',
            'eggs' => 'required|array|min:1|max:50',
            'eggs.*.download_url' => 'required|url|max:2048',
            'eggs.*.egg_id' => 'nullable|string|max:255',
        ]);

        $replace = $request->boolean('replace');
        $result = $this->catalogService->importManyFromUrls($validated['eggs'], (int) $nest->id, $replace);

        $status = count($result['imported']) > 0 ? 200 : 422;

        return response()->json([
            'success' => count($result['imported']) > 0,
            'imported' => $result['imported'],
            'failed' => $result['failed'],
        ], $status);
    }

    /**
     * Import uploaded JSON files into this nest (reuses stock EggImporterService).
     */
    public function importFiles(Request $request, Nest $nest, EggImporterService $importerService): JsonResponse
    {
        $validated = $request->validate([
            'import_files' => 'required|array|min:1',
            'import_files.*' => 'required|file|mimes:json,txt|max:2048',
            'replace' => 'sometimes|boolean',
        ]);

        $replace = $request->boolean('replace');
        $imported = [];
        $failed = [];

        foreach ($request->file('import_files', []) as $file) {
            try {
                $raw = file_get_contents($file->getRealPath());
                $decoded = is_string($raw) ? json_decode($raw, true) : null;
                $name = is_array($decoded) ? ($decoded['name'] ?? null) : null;

                if (is_string($name) && $name !== '') {
                    $existing = \Pterodactyl\Models\Egg::query()
                        ->where('nest_id', $nest->id)
                        ->where('name', $name)
                        ->first();

                    if ($existing && !$replace) {
                        $failed[] = [
                            'filename' => $file->getClientOriginalName(),
                            'error' => 'Egg "' . $name . '" already exists. Enable replace to overwrite.',
                        ];
                        continue;
                    }

                    if ($existing && $replace) {
                        $egg = app(\Pterodactyl\Services\Eggs\Sharing\EggUpdateImporterService::class)
                            ->handle($existing, $file);
                        $imported[] = [
                            'filename' => $file->getClientOriginalName(),
                            'id' => $egg->id,
                            'name' => $egg->name,
                            'replaced' => true,
                        ];
                        continue;
                    }
                }

                $egg = $importerService->handle($file, (int) $nest->id);
                $imported[] = [
                    'filename' => $file->getClientOriginalName(),
                    'id' => $egg->id,
                    'name' => $egg->name,
                    'replaced' => false,
                ];
            } catch (Throwable $exception) {
                $failed[] = [
                    'filename' => $file->getClientOriginalName(),
                    'error' => $exception->getMessage() ?: 'Import failed for this file.',
                ];
            }
        }

        if (count($imported) > 0) {
            $this->catalogService->clearRelevantCaches();
        }

        return response()->json([
            'success' => count($imported) > 0,
            'imported' => $imported,
            'failed' => $failed,
        ], count($imported) > 0 ? 200 : 422);
    }
}
