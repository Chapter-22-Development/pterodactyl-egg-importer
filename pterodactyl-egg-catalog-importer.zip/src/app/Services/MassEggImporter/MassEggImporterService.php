<?php

/**
 * Nest-scoped egg catalog importer service.
 *
 * Fetches the public eggs.pterodactyl.io catalogue and imports egg JSON from
 * allowlisted hosts (eggs.pterodactyl.io / GitHub) into a specific nest.
 *
 * Copyright (c) 2026 Derek Allison / Chapter22 Hosting
 * Licensed under the MIT License.
 */


namespace Pterodactyl\Services\MassEggImporter;

use Throwable;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Cache;
use Illuminate\Http\UploadedFile;
use Pterodactyl\Models\Egg;
use Pterodactyl\Models\Nest;
use Pterodactyl\Services\Eggs\Sharing\EggImporterService;
use Pterodactyl\Services\Eggs\Sharing\EggUpdateImporterService;

class MassEggImporterService
{
    /**
     * Hostnames allowed for server-side egg JSON fetches.
     */
    public const ALLOWED_HOSTS = [
        'eggs.pterodactyl.io',
        'raw.githubusercontent.com',
        'github.com',
        'objects.githubusercontent.com',
    ];

    public function __construct(
        protected EggImporterService $importerService,
        protected EggUpdateImporterService $updateImporterService,
    ) {
    }

    /**
     * Resolve optional settings: config/egg_catalog.php, then Luna ThemeSettings if present, else default.
     */
    public static function getSetting(string $key, mixed $default = null): mixed
    {
        $configKey = "egg_catalog.{$key}";
        if (function_exists('config') && config()->has($configKey)) {
            return config($configKey);
        }

        if (class_exists(\Pterodactyl\Models\ThemeSettings::class)) {
            try {
                return \Pterodactyl\Models\ThemeSettings::getValue(
                    "addons.mass_egg_importer.settings.{$key}",
                    $default
                );
            } catch (\Throwable) {
                // ThemeSettings present but unusable — fall through to default.
            }
        }

        return $default;
    }

    public static function getCategoriesApiUrl(): string
    {
        return (string) self::getSetting('categories_api_url', 'https://eggs.pterodactyl.io/api/categories.json');
    }

    public static function getEggsApiUrl(): string
    {
        return (string) self::getSetting('eggs_api_url', 'https://eggs.pterodactyl.io/api/eggs.json');
    }

    public static function getRequestTimeout(): int
    {
        return (int) self::getSetting('request_timeout', 20);
    }

    public static function isAllowedUrl(string $url): bool
    {
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return false;
        }

        $parts = parse_url($url);
        if (!is_array($parts)) {
            return false;
        }

        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        if ($scheme !== 'https') {
            return false;
        }

        $host = strtolower((string) ($parts['host'] ?? ''));
        if ($host === '' || !in_array($host, self::ALLOWED_HOSTS, true)) {
            return false;
        }

        // github.com: only allow raw/blob paths that point at repository files.
        if ($host === 'github.com') {
            $path = (string) ($parts['path'] ?? '');
            if (!preg_match('#^/[^/]+/[^/]+/(raw|blob)/.+#', $path)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Convert github.com blob URLs to raw.githubusercontent.com equivalents.
     */
    public static function normalizeEggUrl(string $url): string
    {
        $parts = parse_url($url);
        if (!is_array($parts)) {
            return $url;
        }

        $host = strtolower((string) ($parts['host'] ?? ''));
        $path = (string) ($parts['path'] ?? '');

        if ($host === 'github.com' && preg_match('#^/([^/]+)/([^/]+)/blob/(.+)$#', $path, $m)) {
            return 'https://raw.githubusercontent.com/' . $m[1] . '/' . $m[2] . '/' . $m[3];
        }

        return $url;
    }

    /**
     * @return array{categories: array<int, mixed>, eggs: array<int, mixed>}
     */
    public function fetchCatalogue(): array
    {
        $timeout = max(5, self::getRequestTimeout());
        $categoriesUrl = self::getCategoriesApiUrl();
        $eggsUrl = self::getEggsApiUrl();

        if (!self::isAllowedUrl($categoriesUrl) || !self::isAllowedUrl($eggsUrl)) {
            throw new \RuntimeException('Catalogue API URLs are not on the allowlist.');
        }

        $categoriesResponse = Http::timeout($timeout)->acceptJson()->get($categoriesUrl);
        $eggsResponse = Http::timeout($timeout)->acceptJson()->get($eggsUrl);

        if (!$categoriesResponse->successful() || !$eggsResponse->successful()) {
            throw new \RuntimeException('Failed to fetch egg catalogue.');
        }

        $categories = $categoriesResponse->json();
        $eggs = $eggsResponse->json();

        if (!is_array($categories) || !is_array($eggs)) {
            throw new \RuntimeException('Invalid egg catalogue response.');
        }

        return [
            'categories' => array_values($categories),
            'eggs' => array_values($eggs),
        ];
    }

    /**
     * Download egg JSON from an allowlisted URL into a temporary UploadedFile.
     */
    public function downloadEggFile(string $url, ?string $eggId = null): UploadedFile
    {
        $url = self::normalizeEggUrl($url);

        if (!self::isAllowedUrl($url)) {
            throw new \InvalidArgumentException('Only trusted egg sources are allowed.');
        }

        $timeout = max(5, self::getRequestTimeout());
        $response = Http::timeout($timeout)
            ->withHeaders(['Accept' => 'application/json, text/plain, */*'])
            ->get($url);

        if (!$response->successful()) {
            throw new \RuntimeException('Failed to download egg file.');
        }

        $raw = (string) $response->body();
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            throw new \RuntimeException('Downloaded egg file is invalid JSON.');
        }

        $tempPath = tempnam(sys_get_temp_dir(), 'mass_egg_');
        if (!is_string($tempPath) || $tempPath === '') {
            throw new \RuntimeException('Failed to prepare temporary file for import.');
        }

        file_put_contents($tempPath, json_encode($decoded, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));

        $safeEggId = preg_replace('/[^a-zA-Z0-9._-]+/', '-', (string) ($eggId ?? 'egg'));
        $filename = 'egg-' . trim((string) $safeEggId, '-_.') . '.json';
        if ($filename === 'egg-.json' || $filename === 'egg.json') {
            $filename = 'egg-import.json';
        }

        return new UploadedFile($tempPath, $filename, 'application/json', null, true);
    }

    /**
     * Import a single egg into a nest from a remote URL.
     *
     * @return array{egg: Egg, replaced: bool}
     */
    public function importFromUrl(string $url, int $nestId, bool $replace = false, ?string $eggId = null): array
    {
        Nest::query()->findOrFail($nestId);

        $uploadedFile = $this->downloadEggFile($url, $eggId);
        $tempPath = $uploadedFile->getPathname();

        try {
            $parsedName = null;
            $raw = @file_get_contents($tempPath);
            if (is_string($raw)) {
                $decoded = json_decode($raw, true);
                if (is_array($decoded) && isset($decoded['name']) && is_string($decoded['name'])) {
                    $parsedName = $decoded['name'];
                }
            }

            $existing = null;
            if ($parsedName !== null) {
                $existing = Egg::query()
                    ->where('nest_id', $nestId)
                    ->where('name', $parsedName)
                    ->first();
            }

            if ($existing && !$replace) {
                throw new \RuntimeException(
                    'An egg named "' . $parsedName . '" already exists in this nest. Enable replace to overwrite it.'
                );
            }

            if ($existing && $replace) {
                $egg = $this->updateImporterService->handle($existing, $uploadedFile);

                return ['egg' => $egg, 'replaced' => true];
            }

            $egg = $this->importerService->handle($uploadedFile, $nestId);

            return ['egg' => $egg, 'replaced' => false];
        } finally {
            if (is_string($tempPath) && is_file($tempPath)) {
                @unlink($tempPath);
            }
        }
    }

    /**
     * Import multiple eggs by download URL into one nest.
     *
     * @param  array<int, array{download_url: string, egg_id?: string|null}>  $items
     * @return array{imported: array<int, mixed>, failed: array<int, mixed>}
     */
    public function importManyFromUrls(array $items, int $nestId, bool $replace = false): array
    {
        $imported = [];
        $failed = [];

        foreach ($items as $item) {
            $downloadUrl = (string) ($item['download_url'] ?? '');
            $eggId = isset($item['egg_id']) ? (string) $item['egg_id'] : null;

            try {
                $result = $this->importFromUrl($downloadUrl, $nestId, $replace, $eggId);
                $egg = $result['egg'];
                $imported[] = [
                    'id' => $egg->id,
                    'name' => $egg->name,
                    'nest_id' => $egg->nest_id,
                    'replaced' => $result['replaced'],
                    'egg_id' => $eggId,
                ];
            } catch (Throwable $exception) {
                $failed[] = [
                    'egg_id' => $eggId,
                    'download_url' => $downloadUrl,
                    'error' => $exception->getMessage(),
                ];
            }
        }

        if (count($imported) > 0) {
            $this->clearRelevantCaches();
        }

        return ['imported' => $imported, 'failed' => $failed];
    }

    public function clearRelevantCaches(): void
    {
        try {
            Cache::flush();
        } catch (Throwable) {
            // ignore
        }

        try {
            Artisan::call('view:clear');
        } catch (Throwable) {
            // ignore
        }
    }
}
