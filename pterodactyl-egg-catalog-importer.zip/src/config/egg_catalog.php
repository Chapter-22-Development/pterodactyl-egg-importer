<?php

/**
 * Optional configuration for the nest-scoped egg catalog importer.
 * Copy to your panel as config/egg_catalog.php (or merge keys into an existing config).
 *
 * Defaults match the public eggs.pterodactyl.io catalogue. Only HTTPS URLs on the
 * service allowlist are accepted at runtime.
 */

return [
    'categories_api_url' => env('EGG_CATALOG_CATEGORIES_URL', 'https://eggs.pterodactyl.io/api/categories.json'),
    'eggs_api_url' => env('EGG_CATALOG_EGGS_URL', 'https://eggs.pterodactyl.io/api/eggs.json'),
    'request_timeout' => (int) env('EGG_CATALOG_TIMEOUT', 20),
];
