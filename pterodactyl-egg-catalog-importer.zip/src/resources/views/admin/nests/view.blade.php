@extends('layouts.admin')

@section('title')
    Nests &mdash; {{ $nest->name }}
@endsection

@section('content-header')
    <h1>{{ $nest->name }}<small>{{ str_limit($nest->description, 50) }}</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li><a href="{{ route('admin.nests') }}">Nests</a></li>
        <li class="active">{{ $nest->name }}</li>
    </ol>
@endsection

@section('content')
<div class="row">
    <form action="{{ route('admin.nests.view', $nest->id) }}" method="POST">
        <div class="col-md-6">
            <div class="box">
                <div class="box-body">
                    <div class="form-group">
                        <label class="control-label">Name <span class="field-required"></span></label>
                        <div>
                            <input type="text" name="name" class="form-control" value="{{ $nest->name }}" />
                            <p class="text-muted"><small>This should be a descriptive category name that encompasses all of the options within the service.</small></p>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Description</label>
                        <div>
                            <textarea name="description" class="form-control" rows="7">{{ $nest->description }}</textarea>
                        </div>
                    </div>
                </div>
                <div class="box-footer">
                    {!! csrf_field() !!}
                    <button type="submit" name="_method" value="PATCH" class="btn btn-primary btn-sm pull-right">Save</button>
                    <button id="deleteButton" type="submit" name="_method" value="DELETE" class="btn btn-sm btn-danger muted muted-hover"><i class="fa fa-trash-o"></i></button>
                </div>
            </div>
        </div>
    </form>
    <div class="col-md-6">
        <div class="box">
            <div class="box-body">
                <div class="form-group">
                    <label class="control-label">Nest ID</label>
                    <div>
                        <input type="text" readonly class="form-control" value="{{ $nest->id }}" />
                        <p class="text-muted small">A unique ID used for identification of this nest internally and through the API.</p>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label">Author</label>
                    <div>
                        <input type="text" readonly class="form-control" value="{{ $nest->author }}" />
                        <p class="text-muted small">The author of this service option. Please direct questions and issues to them unless this is an official option authored by <code>support@pterodactyl.io</code>.</p>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label">UUID</label>
                    <div>
                        <input type="text" readonly class="form-control" value="{{ $nest->uuid }}" />
                        <p class="text-muted small">A UUID that all servers using this option are assigned for identification purposes.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xs-12">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Nest Eggs</h3>
                <div class="box-tools">
                    <button type="button" class="btn btn-sm btn-info" data-toggle="modal" data-target="#eggCatalogModal">
                        <i class="fa fa-cloud-download"></i> Import from Catalog
                    </button>
                </div>
            </div>
            <div class="box-body table-responsive no-padding">
                <table class="table table-hover">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th class="text-center">Servers</th>
                        <th class="text-center"></th>
                    </tr>
                    @foreach($nest->eggs as $egg)
                        <tr>
                            <td class="align-middle"><code>{{ $egg->id }}</code></td>
                            <td class="align-middle"><a href="{{ route('admin.nests.egg.view', $egg->id) }}" data-toggle="tooltip" data-placement="right" title="{{ $egg->author }}">{{ $egg->name }}</a></td>
                            <td class="col-xs-8 align-middle">{{ $egg->description }}</td>
                            <td class="text-center align-middle"><code>{{ $egg->servers->count() }}</code></td>
                            <td class="align-middle">
                                <a href="{{ route('admin.nests.egg.export', ['egg' => $egg->id]) }}"><i class="fa fa-download"></i></a>
                            </td>
                        </tr>
                    @endforeach
                </table>
            </div>
            <div class="box-footer">
                <a href="{{ route('admin.nests.egg.new') }}"><button class="btn btn-success btn-sm pull-right">New Egg</button></a>
            </div>
        </div>
    </div>
</div>

{{-- Nest-scoped egg catalog importer --}}
<div class="modal fade" id="eggCatalogModal" tabindex="-1" role="dialog" aria-labelledby="eggCatalogModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="eggCatalogModalLabel">Import from Catalog &mdash; {{ $nest->name }}</h4>
            </div>
            <div class="modal-body">
                <p class="text-muted small">
                    Eggs import into nest <strong>{{ $nest->name }}</strong> (ID {{ $nest->id }}) only.
                    Existing eggs with the same name are not overwritten unless you enable replace.
                    Catalogue is fetched server-side from eggs.pterodactyl.io / GitHub raw JSON.
                </p>

                <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation" class="active"><a href="#catalogBrowseTab" aria-controls="catalogBrowseTab" role="tab" data-toggle="tab">Browse catalog</a></li>
                    <li role="presentation"><a href="#catalogUrlTab" aria-controls="catalogUrlTab" role="tab" data-toggle="tab">Paste JSON URL</a></li>
                </ul>

                <div class="tab-content" style="padding-top:15px;">
                    <div role="tabpanel" class="tab-pane active" id="catalogBrowseTab">
                        <div class="row" style="margin-bottom:10px;">
                            <div class="col-sm-5">
                                <input type="text" class="form-control" id="eggCatalogSearch" placeholder="Search eggs..." />
                            </div>
                            <div class="col-sm-4">
                                <select class="form-control" id="eggCatalogCategory">
                                    <option value="games">games</option>
                                    <option value="">All categories</option>
                                </select>
                            </div>
                            <div class="col-sm-3">
                                <button type="button" class="btn btn-default btn-block" id="eggCatalogRefresh"><i class="fa fa-refresh"></i> Refresh</button>
                            </div>
                        </div>
                        <div id="eggCatalogStatus" class="alert alert-info" style="display:none;"></div>
                        <div style="max-height:360px; overflow:auto; border:1px solid #ddd;">
                            <table class="table table-condensed table-hover" style="margin-bottom:0;">
                                <thead>
                                    <tr>
                                        <th style="width:36px;"><input type="checkbox" id="eggCatalogSelectAll" title="Select visible" /></th>
                                        <th>Name</th>
                                        <th>Category</th>
                                        <th style="width:90px;"></th>
                                    </tr>
                                </thead>
                                <tbody id="eggCatalogBody">
                                    <tr><td colspan="4" class="text-center text-muted">Open this modal to load the catalogue...</td></tr>
                                </tbody>
                            </table>
                        </div>
                        <div style="margin-top:12px;" class="clearfix">
                            <label class="checkbox-inline" style="margin-right:15px;">
                                <input type="checkbox" id="eggCatalogReplace" /> Replace existing eggs with the same name
                            </label>
                            <button type="button" class="btn btn-primary pull-right" id="eggCatalogImportSelected" disabled>
                                <i class="fa fa-download"></i> Import selected (<span id="eggCatalogSelectedCount">0</span>)
                            </button>
                        </div>
                    </div>

                    <div role="tabpanel" class="tab-pane" id="catalogUrlTab">
                        <div class="form-group">
                            <label for="eggCatalogPasteUrl">Egg JSON URL</label>
                            <input type="url" class="form-control" id="eggCatalogPasteUrl" placeholder="https://raw.githubusercontent.com/.../egg-something.json" />
                            <p class="help-block small">
                                Allowed hosts: <code>eggs.pterodactyl.io</code>, <code>raw.githubusercontent.com</code>,
                                <code>github.com</code> (blob/raw), <code>objects.githubusercontent.com</code>.
                            </p>
                        </div>
                        <label class="checkbox-inline" style="margin-bottom:10px;">
                            <input type="checkbox" id="eggCatalogUrlReplace" /> Replace existing egg with the same name
                        </label>
                        <div>
                            <button type="button" class="btn btn-primary" id="eggCatalogImportUrl">
                                <i class="fa fa-cloud-download"></i> Import from URL
                            </button>
                        </div>
                        <div id="eggCatalogUrlStatus" class="alert" style="display:none; margin-top:12px;"></div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
@endsection

@section('footer-scripts')
    @parent
    <script>
        $('#deleteButton').on('mouseenter', function (event) {
            $(this).find('i').html(' Delete Nest');
        }).on('mouseleave', function (event) {
            $(this).find('i').html('');
        });

        (function () {
            var catalogueUrl = @json(route('admin.nests.egg-catalog.catalogue', $nest->id));
            var importUrl = @json(route('admin.nests.egg-catalog.import', $nest->id));
            var importBulkUrl = @json(route('admin.nests.egg-catalog.import-bulk', $nest->id));
            var csrf = $('meta[name="_token"]').attr('content');
            var catalogue = [];
            var loaded = false;
            var loading = false;

            function setStatus(msg, type) {
                var el = $('#eggCatalogStatus');
                if (!msg) { el.hide().text(''); return; }
                el.removeClass('alert-info alert-danger alert-success alert-warning')
                    .addClass('alert-' + (type || 'info'))
                    .text(msg)
                    .show();
            }

            function setUrlStatus(msg, type) {
                var el = $('#eggCatalogUrlStatus');
                if (!msg) { el.hide().text(''); return; }
                el.removeClass('alert-info alert-danger alert-success alert-warning')
                    .addClass('alert-' + (type || 'info'))
                    .text(msg)
                    .show();
            }

            function escapeHtml(str) {
                return String(str == null ? '' : str)
                    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
                    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
            }

            function filteredEggs() {
                var term = ($('#eggCatalogSearch').val() || '').toLowerCase().trim();
                var cat = $('#eggCatalogCategory').val() || '';
                return catalogue.filter(function (egg) {
                    if (cat && String(egg.category || '') !== cat) return false;
                    if (!term) return true;
                    var hay = [egg.name, egg.description, egg.id, egg.category, egg.filePath]
                        .map(function (v) { return String(v || '').toLowerCase(); })
                        .join(' ');
                    return hay.indexOf(term) !== -1;
                });
            }

            function updateSelectedCount() {
                var n = $('#eggCatalogBody input.egg-catalog-check:checked').length;
                $('#eggCatalogSelectedCount').text(n);
                $('#eggCatalogImportSelected').prop('disabled', n === 0);
            }

            function renderTable() {
                var eggs = filteredEggs();
                var body = $('#eggCatalogBody');
                if (!eggs.length) {
                    body.html('<tr><td colspan="4" class="text-center text-muted">No eggs match your filters.</td></tr>');
                    updateSelectedCount();
                    return;
                }
                var html = '';
                eggs.forEach(function (egg) {
                    html += '<tr>';
                    html += '<td><input type="checkbox" class="egg-catalog-check" data-id="' + escapeHtml(egg.id || '') + '" data-url="' + escapeHtml(egg.downloadUrl || '') + '" /></td>';
                    html += '<td><strong>' + escapeHtml(egg.name || egg.id || 'Unnamed') + '</strong>';
                    if (egg.description) {
                        html += '<br><span class="text-muted small">' + escapeHtml(String(egg.description).slice(0, 140)) + (String(egg.description).length > 140 ? '…' : '') + '</span>';
                    }
                    html += '</td>';
                    html += '<td><code>' + escapeHtml(egg.category || '') + '</code></td>';
                    html += '<td><button type="button" class="btn btn-xs btn-primary egg-catalog-one" data-id="' + escapeHtml(egg.id || '') + '" data-url="' + escapeHtml(egg.downloadUrl || '') + '">Import</button></td>';
                    html += '</tr>';
                });
                body.html(html);
                updateSelectedCount();
            }

            function populateCategories(categories) {
                var select = $('#eggCatalogCategory');
                var current = select.val() || 'games';
                var opts = '<option value="games">games</option><option value="">All categories</option>';
                (categories || []).forEach(function (c) {
                    var name = typeof c === 'string' ? c : (c && c.name ? c.name : '');
                    if (!name || name === 'games') return;
                    opts += '<option value="' + escapeHtml(name) + '">' + escapeHtml(name) + (c.count ? ' (' + c.count + ')' : '') + '</option>';
                });
                select.html(opts);
                if (select.find('option[value="' + current + '"]').length) {
                    select.val(current);
                } else {
                    select.val('games');
                }
            }

            function loadCatalogue(force) {
                if (loading) return;
                if (loaded && !force) { renderTable(); return; }
                loading = true;
                setStatus('Loading catalogue from eggs.pterodactyl.io…', 'info');
                $('#eggCatalogBody').html('<tr><td colspan="4" class="text-center text-muted">Loading…</td></tr>');

                fetch(catalogueUrl, {
                    method: 'GET',
                    headers: { 'Accept': 'application/json', 'X-CSRF-TOKEN': csrf },
                    credentials: 'same-origin'
                })
                    .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, data: d }; }); })
                    .then(function (res) {
                        loading = false;
                        if (!res.ok || !Array.isArray(res.data.eggs)) {
                            setStatus(res.data.error || 'Failed to load catalogue.', 'danger');
                            return;
                        }
                        catalogue = res.data.eggs;
                        loaded = true;
                        populateCategories(res.data.categories || []);
                        setStatus('Loaded ' + catalogue.length + ' eggs. Showing category filter: games by default.', 'success');
                        renderTable();
                    })
                    .catch(function () {
                        loading = false;
                        setStatus('Failed to load catalogue.', 'danger');
                    });
            }

            function doImport(items, replace, onDone) {
                if (!items.length) return;
                setStatus('Importing ' + items.length + ' egg(s)…', 'info');

                var payload = { replace: !!replace, eggs: items };
                var url = items.length === 1 ? importUrl : importBulkUrl;
                var body = items.length === 1
                    ? JSON.stringify({ download_url: items[0].download_url, egg_id: items[0].egg_id || null, replace: !!replace })
                    : JSON.stringify(payload);

                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': csrf,
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    credentials: 'same-origin',
                    body: body
                })
                    .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, status: r.status, data: d }; }); })
                    .then(function (res) {
                        if (items.length === 1) {
                            if (res.data.success) {
                                setStatus('Imported: ' + (res.data.egg && res.data.egg.name ? res.data.egg.name : 'egg') + (res.data.replaced ? ' (replaced)' : '') + '. Reloading…', 'success');
                                setTimeout(function () { window.location.reload(); }, 900);
                            } else {
                                setStatus(res.data.error || 'Import failed.', res.status === 409 ? 'warning' : 'danger');
                            }
                        } else {
                            var imported = (res.data.imported || []).length;
                            var failed = (res.data.failed || []).length;
                            if (imported > 0) {
                                setStatus('Imported ' + imported + ' egg(s)' + (failed ? ', ' + failed + ' failed' : '') + '. Reloading…', failed ? 'warning' : 'success');
                                setTimeout(function () { window.location.reload(); }, 1100);
                            } else {
                                var firstErr = (res.data.failed && res.data.failed[0] && res.data.failed[0].error) || res.data.error || 'No eggs imported.';
                                setStatus(firstErr, 'danger');
                            }
                        }
                        if (typeof onDone === 'function') onDone(res);
                    })
                    .catch(function () {
                        setStatus('Import request failed.', 'danger');
                        if (typeof onDone === 'function') onDone(null);
                    });
            }

            $('#eggCatalogModal').on('shown.bs.modal', function () { loadCatalogue(false); });
            $('#eggCatalogRefresh').on('click', function () { loadCatalogue(true); });
            $('#eggCatalogSearch, #eggCatalogCategory').on('input change', function () { renderTable(); });

            $('#eggCatalogSelectAll').on('change', function () {
                var checked = $(this).is(':checked');
                $('#eggCatalogBody input.egg-catalog-check').prop('checked', checked);
                updateSelectedCount();
            });

            $(document).on('change', '#eggCatalogBody input.egg-catalog-check', updateSelectedCount);

            $(document).on('click', '.egg-catalog-one', function () {
                var url = $(this).data('url');
                var id = $(this).data('id');
                if (!url) { setStatus('Missing download URL for this egg.', 'danger'); return; }
                doImport([{ download_url: url, egg_id: id }], $('#eggCatalogReplace').is(':checked'));
            });

            $('#eggCatalogImportSelected').on('click', function () {
                var items = [];
                $('#eggCatalogBody input.egg-catalog-check:checked').each(function () {
                    var url = $(this).data('url');
                    var id = $(this).data('id');
                    if (url) items.push({ download_url: url, egg_id: id });
                });
                doImport(items, $('#eggCatalogReplace').is(':checked'));
            });

            $('#eggCatalogImportUrl').on('click', function () {
                var url = ($('#eggCatalogPasteUrl').val() || '').trim();
                if (!url) { setUrlStatus('Paste a JSON URL first.', 'warning'); return; }
                setUrlStatus('Importing…', 'info');
                fetch(importUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': csrf,
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    credentials: 'same-origin',
                    body: JSON.stringify({
                        download_url: url,
                        replace: $('#eggCatalogUrlReplace').is(':checked')
                    })
                })
                    .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, status: r.status, data: d }; }); })
                    .then(function (res) {
                        if (res.data.success) {
                            setUrlStatus('Imported: ' + (res.data.egg && res.data.egg.name ? res.data.egg.name : 'egg') + '. Reloading…', 'success');
                            setTimeout(function () { window.location.reload(); }, 900);
                        } else {
                            setUrlStatus(res.data.error || 'Import failed.', res.status === 409 ? 'warning' : 'danger');
                        }
                    })
                    .catch(function () { setUrlStatus('Import request failed.', 'danger'); });
            });
        })();
    </script>
@endsection
