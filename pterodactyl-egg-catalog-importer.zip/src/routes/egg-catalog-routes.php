<?php

/**
 * Nest-scoped egg catalog routes — merge into routes/admin.php inside the
 * existing Route::group(['prefix' => 'nests'], ...) block, near the other
 * nest/egg routes (after admin.nests.egg.import is a good place).
 *
 * These routes require NestEggCatalogController to be available under
 * Pterodactyl\Http\Controllers\Admin\Nests.
 */

use Illuminate\Support\Facades\Route;
use Pterodactyl\Http\Controllers\Admin;

// Nest-scoped egg catalog importer (server-side fetch from eggs.pterodactyl.io / GitHub raw)
Route::get('/view/{nest:id}/egg-catalog', [Admin\Nests\NestEggCatalogController::class, 'catalogue'])->name('admin.nests.egg-catalog.catalogue');
Route::post('/view/{nest:id}/egg-catalog/import', [Admin\Nests\NestEggCatalogController::class, 'import'])->name('admin.nests.egg-catalog.import');
Route::post('/view/{nest:id}/egg-catalog/import-bulk', [Admin\Nests\NestEggCatalogController::class, 'importBulk'])->name('admin.nests.egg-catalog.import-bulk');
Route::post('/view/{nest:id}/egg-catalog/import-files', [Admin\Nests\NestEggCatalogController::class, 'importFiles'])->name('admin.nests.egg-catalog.import-files');
